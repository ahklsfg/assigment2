#include <stdio.h>
int main() {
printf("This is a simple program.\n");
return 0;
}
